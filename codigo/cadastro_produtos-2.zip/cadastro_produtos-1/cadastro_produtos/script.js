function leDados(){
    let strDados = localStorage.getItem('db');
    let objDados = {};
    
    if(strDados && strDados !== "undefined" && strDados !== "null")
        objDados = JSON.parse(strDados);
    return objDados;
}

function salvaDados(dados) {
    localStorage.setItem('db', JSON.stringify (dados));
}
//----------------------------------------------------------------------INCLUIR
function incluirDados(){    
    //ler os dados do localStorage
    let objDados = leDados();

    //incluir um novo dado
    let tituloDoProduto = document.getElementById('inputTitulo').value;
    let nomeDoProduto = document.getElementById('inputNomeProduto').value;
    let descricaoDoProduto = document.getElementById('descricaoDoProduto').value;
    let valorDeVenda = document.getElementById('inputValor').value;
    let inputImagem = document.getElementById('inputFile'). files[0];

    let coresSelecionadas = [];
    document.querySelectorAll('input[type=checkbox][id^=cor]:checked').forEach(checkbox => {
        coresSelecionadas.push(checkbox.value);
    });

    let tamanhosSelecionados = [];
    document.querySelectorAll('input[type=checkbox][id^=tam]:checked').forEach(checkbox => {
        tamanhosSelecionados.push(checkbox.value);
    });

    if (tituloDoProduto === '' || nomeDoProduto === '' || descricaoDoProduto === '' || valorDeVenda === '' || !inputImagem) {
        alert('Por favor, preencha todos os campos antes de adicionar um produto.');
        return;
    }

    //leitor de imagens
    let reader = new FileReader();
    reader.onload = function(event){
        let imagemBase64 = event.target.result;
        
        //verificar se há uma lista de produtos, se não, cria uma -- esta criando a propriedade produtos em objDados
        if(!objDados.produtos)
            objDados.produtos = [];
        
        
        objDados.produtos.push({
            titulo: tituloDoProduto,
            nome: nomeDoProduto,
            descricao: descricaoDoProduto,
            valor: valorDeVenda,
            imagem: imagemBase64,
            cores: coresSelecionadas,
            tamanhos: tamanhosSelecionados
        });
        
        //salvar os dados no localStorage
        salvaDados(objDados);
        
        //limpar os campos do formulário
        document.getElementById('inputTitulo').value = '';
        document.getElementById('inputNomeProduto').value = '';
        document.getElementById('descricaoDoProduto').value = '';
        document.getElementById('inputValor').value = '';
        document.getElementById('inputFile').value = '';
        document.querySelectorAll('input[type=checkbox]').forEach(checkbox => checkbox.checked = false);
    };

    reader.readAsDataURL(inputImagem);
}
//---------------------------------------------------------------------------ALTERAR
function alterarDados() {
    let objDados = leDados();
    let nomeDoProduto = document.getElementById('inputNomeProduto').value;
    let produto = objDados.produtos.find(p => p.nome === nomeDoProduto);

    if(!produto) {
        alert('Produto não encontrado!');
        return;
    }

    let tituloDoProduto = document.getElementById('inputTitulo').value;
    let descricaoDoProduto = document.getElementById('descricaoDoProduto').value;
    let valorDeVenda = document.getElementById('inputValor').value;
    let inputImagem = document.getElementById('inputFile').files[0];

    let coresSelecionadas = [];
    document.querySelectorAll('input[type=checkbox][id^=cor]:checked').forEach(checkbox => {
        coresSelecionadas.push(checkbox.value);
    });

    let tamanhosSelecionados = [];
    document.querySelectorAll('input[type=checkbox][id^=tam]:checked').forEach(checkbox => {
        tamanhosSelecionados.push(checkbox.value);
    });

    if (tituloDoProduto !== '') 
        produto.titulo = tituloDoProduto;

    if (descricaoDoProduto !== '')
        produto.descricao = descricaoDoProduto;

    if (valorDeVenda !== '')
        produto.valor = valorDeVenda;

    if (coresSelecionadas.length > 0) 
        produto.cores = coresSelecionadas;

    if (tamanhosSelecionados.length > 0) 
        produto.tamanhos = tamanhosSelecionados;

    if (inputImagem) {
        let reader = new FileReader();
        reader.onload = function(event) {
            let imagemBase64 = event.target.result;
            produto.imagem = imagemBase64;
            salvaDados(objDados);
        };
        reader.readAsDataURL(inputImagem);
        
    } else {
        salvaDados(objDados);
        alert('Produto alterado com sucesso!');
    }

    alert('Produto alterado com sucesso!');

    document.getElementById('inputTitulo').value = '';
        document.getElementById('inputNomeProduto').value = '';
        document.getElementById('descricaoDoProduto').value = '';
        document.getElementById('inputValor').value = '';
        document.getElementById('inputFile').value = '';
}
//--------------------------------------------------------------------------------EXCLUIR
function excluirDados() {
    let objDados = leDados();
    let nomeDoProduto = document.getElementById('inputNomeProduto').value;
    objDados.produtos = objDados.produtos.filter(p => p.nome !== nomeDoProduto);
    salvaDados(objDados);
    
    alert('Produto excluído com sucesso!');

    document.getElementById('inputTitulo').value = '';
    document.getElementById('inputNomeProduto').value = '';
    document.getElementById('descricaoDoProduto').value = '';
    document.getElementById('inputValor').value = '';
    document.getElementById('inputFile').value = '';
}

document.getElementById('incluir').addEventListener('click', incluirDados);
document.getElementById('alterar').addEventListener('click', alterarDados);
document.getElementById('excluir').addEventListener('click', excluirDados);