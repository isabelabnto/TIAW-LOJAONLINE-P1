document.addEventListener("DOMContentLoaded", function() {
    // Código JavaScript para interatividade da página

    // Exemplo de exibição de alerta ao clicar no botão de finalizar compra
    document.querySelector(".finalize-button").addEventListener("click", function() {
        alert("Compra finalizada com sucesso!");
    });
});
