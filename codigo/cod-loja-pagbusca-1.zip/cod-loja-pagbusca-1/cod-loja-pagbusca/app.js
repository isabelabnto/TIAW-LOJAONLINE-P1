// Funções para manipulação do localStorage
function leDados() {
    let strDados = localStorage.getItem('db');
    let objDados = {};

    if (strDados && strDados !== "undefined" && strDados !== "null")
        objDados = JSON.parse(strDados);
    return objDados;
}

function salvaDados(dados) {
    localStorage.setItem('db', JSON.stringify(dados));
}

// Carregar produtos do localStorage e exibi-los
document.addEventListener("DOMContentLoaded", function() {
    let objDados = leDados();
    
    if (!objDados.produtos || objDados.produtos.length === 0) {
        console.warn('Nenhum produto encontrado no localStorage.');
    } else {
        carregarProdutos(objDados.produtos);
    }
});

// Função para carregar produtos na página
function carregarProdutos(produtos) {
    const seccaoProdutos = document.querySelector('.produtos');
    seccaoProdutos.innerHTML = ''; // Limpa a seção de produtos

    produtos.forEach(produto => {
        const divProduto = document.createElement('div');
        divProduto.className = 'produto';
        divProduto.setAttribute('data-termo-busca', produto.nome.toLowerCase());

        const imgProduto = document.createElement('img');
        imgProduto.src = produto.imagem;
        imgProduto.alt = produto.descricao;

        const h3Produto = document.createElement('h3');
        h3Produto.textContent = produto.nome;

        const pProduto = document.createElement('p');
        pProduto.textContent = `R$ ${parseFloat(produto.valor).toFixed(2)}`;

        const divAvaliacoes = document.createElement('div');
        divAvaliacoes.className = 'avaliacoes';

        for (let i = 0; i < 5; i++) {
            const spanEstrela = document.createElement('span');
            spanEstrela.className = 'estrela';
            spanEstrela.style.color = i < 4 ? '#ffcb0c' : '#ccc'; 
            spanEstrela.textContent = '★';
            divAvaliacoes.appendChild(spanEstrela);
        }

        divProduto.appendChild(imgProduto);
        divProduto.appendChild(h3Produto);
        divProduto.appendChild(pProduto);
        divProduto.appendChild(divAvaliacoes);
        seccaoProdutos.appendChild(divProduto);
    });
}

// Função de busca de produtos
function buscarRoupas(event) {
    event.preventDefault(); 
    const termoBusca = document.getElementById('busca').value.toLowerCase();
    const produtos = document.querySelectorAll('.produto');
    const seccaoProdutos = document.querySelector('.produtos');

    let encontrou = false;

    produtos.forEach(produto => {
        const termoProduto = produto.getAttribute('data-termo-busca').toLowerCase();
        if (termoProduto.includes(termoBusca)) {
            produto.style.display = 'block';
            encontrou = true;
        } else {
            produto.style.display = 'none';
        }
    });

    const resultadoTitulo = document.getElementById('resultado-titulo');
    if (encontrou) {
        resultadoTitulo.innerHTML = `Resultados da Pesquisa por "${termoBusca}"`;
        seccaoProdutos.style.display = 'grid';
    } else {
        resultadoTitulo.innerHTML = `Nenhum resultado encontrado para "${termoBusca}"`;
        seccaoProdutos.style.display = 'block';
    }
}

document.getElementById('form-busca').addEventListener('submit', buscarRoupas);
