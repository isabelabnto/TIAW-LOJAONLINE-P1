const http = require('http');
const path = require('path');
const express = require('express');
const fs = require('fs');
const session = require('express-session');

const app = express();
const server = http.createServer(app);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({ secret: "abc", resave: false, saveUninitialized: true }));

app.set('port', process.env.PORT || 3000);

app.use('/acesso-restrito/*', (req, res, next) => {
  if (req.session.email) {
    next();
  } else {
    res.redirect('/index.html');
  }
});

app.use(express.static(path.join(__dirname, 'public')));

server.listen(app.get('port'), () => {
  console.log('Server running on port', app.get('port'));
});

app.post('/login', (req, res) => {
  const usuarioscad = fs.readFileSync('./usuarios.json');
  const usuariosparse = JSON.parse(usuarioscad);

  const { email, senha } = req.body;

  for (const umUsuario of usuariosparse) {
    if (email === umUsuario.email && senha === umUsuario.senha) {
      req.session.email = umUsuario.email;
      res.send('Conectado');
      return;
    }
  }
  res.send('Email ou senha inválidos');
});

app.post('/cadastro', (req, res) => {
  const usuarioscad = fs.readFileSync('./usuarios.json');
  const usuariosparse = JSON.parse(usuarioscad);

  const { email, senha } = req.body;

  const datauser = { email, senha };

  usuariosparse.push(datauser);

  fs.writeFile('./usuarios.json', JSON.stringify(usuariosparse, null, 4), (error) => {
    if (error) {
      console.error(error);
      res.status(500).send('Erro ao salvar usuário');
      return;
    }
    res.send('Usuário cadastrado com sucesso');
  });
});

